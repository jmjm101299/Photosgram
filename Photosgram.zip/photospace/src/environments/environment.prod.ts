export const environment = {
  production: true,
  url: 'http://192.168.0.10:3000'
};
