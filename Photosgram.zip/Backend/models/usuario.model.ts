import {Schema, model, Document} from 'mongoose'
import express from 'express';
import bcrypt from 'bcrypt';

const usuarioSchema = new Schema({
    nombre:{
        type:String,
        required: [true, 'Ingresar Nombre es Obligatorio']
    },
    avatar:{
        type:String,
        default: 'av-1.png'
    },
    email:{
        type:String,
        unique: true,
        required:[true,'E-Mail obligatorio']
    },
    password:{
        type: String,
        required: [true, 'Password es obligatorio']
    }


});

usuarioSchema.method('compararPassword',function(password:string=''):boolean{
    if(bcrypt.compareSync(password, this.password)){
        return true;
    }else{
        return false;
    }
});

interface IUsuario extends Document{
    nombre:string;
    email:string;
    password:string;
    avatar:string;
    compararPassword(password:string):boolean;
}

export const Usuario = model<IUsuario>('Usuario',usuarioSchema);